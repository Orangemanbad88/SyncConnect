// Common type definitions for the Sync app

export type TimeOfDay = 'dawn' | 'day' | 'sunset' | 'night';